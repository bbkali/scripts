const char * n2n_sw_version   = N2N_VERSION;
const char * n2n_sw_osName    = N2N_OSNAME;
const char * n2n_sw_buildDate = __DATE__ " " __TIME__;
