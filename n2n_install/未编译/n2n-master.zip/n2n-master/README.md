This repository is maintained very sparsely
===========================================

Consider using the version at https://github.com/ntop/n2n
as a lot of improvements from here have been ported to over
there.


This is a development branch of the n2n p2p vpn software.

https://github.com/ntop/n2n

It contains some modifications of the v2 version of n2n, which is the latest stable version
and should be used for productive environments.
All the current development happens in this repository in the new_protocol branch, which is 
intended to be come version v3 of n2n and then merged back into the original svn repository
on ntop.org.

Uses sglib http://sglib.sourceforge.net.

For further information please visit the wiki https://github.com/meyerd/n2n/wiki.
